package com.junit.demo;

public class Greetings {
	
	public String sayHello() {
		return "Hello";
	}
}
